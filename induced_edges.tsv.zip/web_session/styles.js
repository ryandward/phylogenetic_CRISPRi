var styles = [ {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.10.1",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "default",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "border-opacity" : 1.0,
      "border-width" : 0.0,
      "text-valign" : "center",
      "text-halign" : "center",
      "color" : "rgb(0,0,0)",
      "font-size" : 12,
      "shape" : "roundrectangle",
      "height" : 35.0,
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal",
      "text-opacity" : 1.0,
      "border-color" : "rgb(204,204,204)",
      "background-opacity" : 1.0,
      "background-color" : "rgb(137,208,245)",
      "width" : 35.0,
      "content" : "data(name)"
    }
  }, {
    "selector" : "node[Direction = 'Down']",
    "css" : {
      "background-color" : "rgb(253,187,132)"
    }
  }, {
    "selector" : "node[Direction = 'Up']",
    "css" : {
      "background-color" : "rgb(198,219,239)"
    }
  }, {
    "selector" : "node[type = 'gene']",
    "css" : {
      "shape" : "ellipse"
    }
  }, {
    "selector" : "node[type = 'term']",
    "css" : {
      "shape" : "rectangle"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,255,0)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "line-color" : "rgb(132,132,132)",
      "source-arrow-color" : "rgb(0,0,0)",
      "width" : 2.0,
      "opacity" : 1.0,
      "target-arrow-shape" : "none",
      "line-style" : "solid",
      "target-arrow-color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "color" : "rgb(0,0,0)",
      "font-size" : 10,
      "font-family" : "Dialog.plain",
      "font-weight" : "normal",
      "text-opacity" : 1.0,
      "content" : ""
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
} ]